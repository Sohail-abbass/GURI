//   the input area  is empty at start
let string = "";
let display=document.getElementById("space")
// now we target every button and add avent listner
let buttons=document.querySelectorAll(".button");
let buttonarray = Array.from(buttons);
buttonarray.forEach((bttn)=>{
    bttn.addEventListener("click",(e)=>{
        if(e.target.innerHTML=="dell"){
            string= string.substring(0,string.length-1)
            display.value=string;
        
        }
        else if(e.target.innerHTML=="reset"){
            string= "";
            display.value=string;
        }
        else if(e.target.innerHTML=="="){
            string=eval(string);
            display.value=string;
        }
        else{
        
        string = string + e.target.innerHTML;
        display.value=string;
        }
    })
})

